﻿using EmailConfigurationWebApi.Model;
using System.Web.Http.ModelBinding;

namespace EmailConfigurationWebApi.Service
{
    public class EmailConfigureService
    {
        private readonly EmailConfigureContext _context;

        public EmailConfigureService(EmailConfigureContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<EmailConfigure>> GetEmailConfigures()
        {
            //if (!ModelState.IsValid)
            //{
            //    return Message;
            //}
            var emailConfigures =  _context.EmailConfigures.ToList();
            if (_context.EmailConfigures == null)
            {
                return null; // Error Handel
            }
            return emailConfigures;
        }

        public async Task<EmailConfigure> GetEmailConfigure(int id)
        {
            var emailConfigure = await _context.EmailConfigures.FindAsync(id);
            var emailConfigures = _context.EmailConfigures.ToList();

            if (emailConfigure == null)
            {
                return null; // Error Handel
            }

            if (emailConfigures == null)
            {
                return null; // Error Handel
            }
            return emailConfigure;
        }

        public async Task<EmailConfigure> PostEmailConfigure(EmailConfigure emailConfigure)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Message;
            //}

            if (_context.EmailConfigures == null)
            {
                return null; //Problem("Entity set 'EmailConfigureContext.EmailConfigures'  is null.");
            }
            _context.EmailConfigures.Add(emailConfigure);
            await _context.SaveChangesAsync();

            return  CreatedAtAction("GetEmailConfigure", new { id = emailConfigure.EmailId }, emailConfigure);

        }
        private bool EmailConfigureExists(int id)
        {
            return (_context.EmailConfigures?.Any(e => e.EmailId == id)).GetValueOrDefault();
        }

    }
}
