﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmailConfigurationWebApi.Model;
using EmailConfigurationWebApi.Service;

namespace EmailConfigurationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailConfigureController : ControllerBase
    {
        private readonly EmailConfigureContext _context;
        private readonly EmailConfigureService _service;

        public EmailConfigureController(
            EmailConfigureContext context,
            EmailConfigureService service
            )
        {
            _context = context;
            _service = service;
        }

        // GET: api/EmailConfigure
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmailConfigure>>> GetEmailConfigures()
        {

            //try
            //{
            //    List<EmailConfigure> result = await TestEmployeesGetAsync(); _service.GetEmailConfigures();
            //}
            //catch (Exception)
            //{

            //    throw;
            //}

            if (_context.EmailConfigures == null)
            {
                return NotFound();
            }
            return await _context.EmailConfigures.ToListAsync();
        }

        // GET: api/EmailConfigure/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EmailConfigure>> GetEmailConfigure(int id)
        {
            try
            {
                return await _service.GetEmailConfigure(id);
            }
            catch (Exception)
            {
                throw;
            }

            //if (_context.EmailConfigures == null)
            //{
            //    return NotFound();
            //}
            //var emailConfigure = await _context.EmailConfigures.FindAsync(id);

            //if (emailConfigure == null)
            //{
            //    return NotFound();
            //}
        }


        [HttpPost]
        public async Task<ActionResult<EmailConfigure>> PostEmailConfigure(EmailConfigure emailConfigure)
        {
            //if (_context.EmailConfigures == null)
            //{
            //    return Problem("Entity set 'EmailConfigureContext.EmailConfigures'  is null.");
            //}
            //_context.EmailConfigures.Add(emailConfigure);
            //await _context.SaveChangesAsync();

            //return CreatedAtAction("GetEmailConfigure", new { id = emailConfigure.EmailId }, emailConfigure);

            try
            {
                return await _service.PostEmailConfigure(emailConfigure);
            }
            catch (Exception)
            {
                throw;
            }
        }

        //private bool EmailConfigureExists(int id)
        //{
        //    return (_context.EmailConfigures?.Any(e => e.EmailId == id)).GetValueOrDefault();
        //}
    }
}
